Lean Mode static website package

This is a self-contained static website. Upload the contents of this folder to a GitHub repository, then create a Render Static Site connected to that repository.
Build command: (leave blank)
Publish directory: .

The app stores entries in browser local storage, as the original preview did. Export CSV backups regularly. Data is not synchronized between different devices or browsers.

After publishing, open the site in Safari on iPhone, tap Share, then Add to Home Screen.
