# Lean Mode Nutrition API

This small Node.js service proxies USDA FoodData Central searches. The USDA key stays on the server and is never sent to the browser.

## Deploy on Render

1. Add this `nutrition-api` folder to the root of `jclark1388/lean-mode-tracker` on GitHub.
2. In Render, choose **New + → Web Service** and connect that repository.
3. Set **Root Directory** to `nutrition-api`.
4. Set **Build Command** to `npm install` and **Start Command** to `npm start`.
5. Choose a plan and create the service.
6. In the new backend service's **Environment** page add:
   - `USDA_API_KEY` = your USDA key (paste it only in Render)
   - `ALLOWED_ORIGIN` = `https://lean-mode-tracker-final.onrender.com`
7. Save and deploy.

## Test

Open `https://YOUR-BACKEND.onrender.com/health` and expect `{"ok":true}`.
Then open `https://YOUR-BACKEND.onrender.com/api/search?q=greek%20yogurt` and expect a JSON food list.

The tracker frontend still needs to be updated to call `https://YOUR-BACKEND.onrender.com/api/search?q=...` and redeployed. It is not connected until that frontend change is live.
