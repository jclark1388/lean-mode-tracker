const http = require('node:http');
const { URL } = require('node:url');

const PORT = Number(process.env.PORT || 10000);
const API_KEY = process.env.USDA_API_KEY;
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || 'https://lean-mode-tracker-final.onrender.com';

function send(res, status, body) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': ALLOWED_ORIGIN,
    'Vary': 'Origin',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Cache-Control': 'no-store'
  });
  res.end(JSON.stringify(body));
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': ALLOWED_ORIGIN,
      'Vary': 'Origin',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    });
    return res.end();
  }

  const url = new URL(req.url, 'http://localhost');
  if (url.pathname === '/health') return send(res, 200, { ok: true });
  if (url.pathname !== '/api/search' || req.method !== 'GET') {
    return send(res, 404, { error: 'Not found' });
  }
  if (!API_KEY) return send(res, 503, { error: 'Nutrition search is not configured yet.' });

  const query = (url.searchParams.get('q') || '').trim().slice(0, 100);
  if (query.length < 2) return send(res, 400, { error: 'Enter at least 2 characters to search.' });

  try {
    const apiUrl = new URL('https://api.nal.usda.gov/fdc/v1/foods/search');
    apiUrl.searchParams.set('api_key', API_KEY);
    apiUrl.searchParams.set('query', query);
    apiUrl.searchParams.set('pageSize', '10');
    apiUrl.searchParams.set('dataType', 'Foundation,SR Legacy,Branded,FNDDS');
    const upstream = await fetch(apiUrl, { signal: AbortSignal.timeout(10000) });

    if (!upstream.ok) {
      console.error('USDA API returned status', upstream.status);
      return send(res, upstream.status === 429 ? 429 : 502, {
        error: upstream.status === 429
          ? 'Nutrition search is temporarily rate-limited. Try again later.'
          : 'Nutrition database is temporarily unavailable.'
      });
    }

    const data = await upstream.json();
    const foods = (data.foods || []).map(food => {
      const nutrients = food.foodNutrients || [];
      const findNutrient = id => {
        const n = nutrients.find(item => Number(item.nutrientId) === id);
        return n && Number.isFinite(Number(n.value)) ? Number(n.value) : null;
      };
      return {
        fdcId: food.fdcId,
        description: food.description,
        brandOwner: food.brandOwner || '',
        dataType: food.dataType || '',
        servingSize: food.servingSize || null,
        servingSizeUnit: food.servingSizeUnit || '',
        calories: findNutrient(1008),
        protein: findNutrient(1003)
      };
    });
    return send(res, 200, { foods });
  } catch (error) {
    console.error('Nutrition search failed:', error.message);
    return send(res, 502, { error: 'Could not reach the nutrition database. Please try again.' });
  }
});

server.listen(PORT, '0.0.0.0', () => console.log('Nutrition API listening on port', PORT));
